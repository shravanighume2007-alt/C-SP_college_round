
#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include <algorithm>
using namespace std;

vector<string> customers;
vector<string> campaigns;
vector<string> webinars;
vector<string> subscriptions;

void dashboard() {
    cout << "\n===== NEXUS DASHBOARD =====\n";
    cout << "Total Customers: " << customers.size() << endl;
    cout << "Total Campaigns: " << campaigns.size() << endl;
    cout << "Total Webinars: " << webinars.size() << endl;
    cout << "Total Subscriptions: " << subscriptions.size() << endl;
}

void addCustomer() {
    string name, email;

    cout << "Enter customer name: ";
    getline(cin, name);

    cout << "Enter customer email: ";
    getline(cin, email);

    customers.push_back(name + " | " + email);
    cout << "Customer added successfully!\n";
}

void viewCustomers() {
    cout << "\n===== CRM CUSTOMERS =====\n";

    if (customers.empty()) {
        cout << "No customers found.\n";
        return;
    }

    for (string customer : customers) {
        cout << customer << endl;
    }
}

void createCampaign() {
    string name;

    cout << "Enter campaign name: ";
    getline(cin, name);

    campaigns.push_back(name + " (Pending Approval)");
    cout << "Campaign created. Approval is required before launch.\n";
}

void scheduleWebinar() {
    string name, date;

    cout << "Enter webinar name: ";
    getline(cin, name);

    cout << "Enter webinar date: ";
    getline(cin, date);

    webinars.push_back(name + " | Date: " + date);
    cout << "Webinar scheduled successfully!\n";
}

void addSubscription() {
    string name, plan;

    cout << "Enter customer name: ";
    getline(cin, name);

    cout << "Enter subscription plan: ";
    getline(cin, plan);

    subscriptions.push_back(name + " | Plan: " + plan);
    cout << "Subscription added successfully!\n";
}

void viewList(string title, vector<string> items) {
    cout << "\n===== " << title << " =====\n";

    if (items.empty()) {
        cout << "No records found.\n";
        return;
    }

    for (string item : items) {
        cout << item << endl;
    }
}

void aiAgent() {
    string command;

    cout << "\n===== NEXUS AI AGENT =====\n";
    cout << "Try: show customers\n";
    cout << "Try: show campaigns\n";
    cout << "Try: show webinars\n";
    cout << "Try: launch campaign\n";
    cout << "Enter your instruction: ";

    getline(cin, command);

    transform(command.begin(), command.end(), command.begin(),
               [](unsigned char c) { return tolower(c); });

    if (command.find("show") != string::npos &&
        command.find("customer") != string::npos) {
        viewCustomers();
    }
    else if (command.find("show") != string::npos &&
             command.find("campaign") != string::npos) {
        viewList("CAMPAIGNS", campaigns);
    }
    else if (command.find("show") != string::npos &&
             command.find("webinar") != string::npos) {
        viewList("WEBINARS", webinars);
    }
    else if (command.find("launch") != string::npos &&
             command.find("campaign") != string::npos) {
        cout << "Approval required before launching a campaign.\n";
        cout << "Approve launch? (yes/no): ";

        string approval;
        getline(cin, approval);

        if (approval == "yes" || approval == "YES" ||
            approval == "Yes") {
            cout << "Demo approval recorded.\n";
            cout << "Connect a marketing service to launch a real campaign.\n";
        }
        else {
            cout << "Campaign launch cancelled.\n";
        }
    }
    else {
        cout << "Command not recognized. Try another instruction.\n";
    }
}

int main() {
    int choice;

    do {
        cout << "\n========== NEXUS PLATFORM ==========\n";
        cout << "1. Dashboard\n";
        cout << "2. Add Customer\n";
        cout << "3. View Customers\n";
        cout << "4. Create Marketing Campaign\n";
        cout << "5. Schedule Webinar\n";
        cout << "6. Add Subscription\n";
        cout << "7. View Campaigns\n";
        cout << "8. View Webinars\n";
        cout << "9. View Subscriptions\n";
        cout << "10. AI Agent\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";

        if (!(cin >> choice)) {
            cout << "Please enter a valid number.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1:
                dashboard();
                break;
            case 2:
                addCustomer();
                break;
            case 3:
                viewCustomers();
                break;
            case 4:
                createCampaign();
                break;
            case 5:
                scheduleWebinar();
                break;
            case 6:
                addSubscription();
                break;
            case 7:
                viewList("CAMPAIGNS", campaigns);
                break;
            case 8:
                viewList("WEBINARS", webinars);
                break;
            case 9:
                viewList("SUBSCRIPTIONS", subscriptions);
                break;
            case 10:
                aiAgent();
                break;
            case 0:
                cout << "Thank you for using Nexus!\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 0);

    return 0;
}
